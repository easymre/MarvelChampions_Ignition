def tagloop(tagfolder,code,col):

	tagbrowse = system.tag.browse(tagfolder)
	for i in range(len(tagbrowse)):
		keypath = str(tagbrowse[i]['fullPath'])
		keyval = tagbrowse[i]['value']
		dekey = system.util.jsonEncode(keyval)
		dekey = system.util.jsonDecode(dekey)
		codepath = dekey['value']['members']['code']['value']
		if codepath == code:
			tagpath = keypath
	
	tag = system.tag.readBlocking(tagpath)[0]
	dekey_tag = system.util.jsonEncode(tag)
	dekey_tag = system.util.jsonDecode(dekey_tag)
	
	colorpath = dekey_tag['value']['members']['meta']['members']['colors']['elements']
	color = colorpath[col]['value']
	
	return color	

def alterego_code(tagfolder,code):
	tagbrowse = system.tag.browse(tagfolder)
	for i in range(len(tagbrowse)):
		keypath = str(tagbrowse[i]['fullPath'])
		keyval = tagbrowse[i]['value']
		dekey = system.util.jsonEncode(keyval)
		dekey = system.util.jsonDecode(dekey)
		codepath = dekey['value']['members']['code']['value']
		#cardtype = dekey['value']['members']['type_name']['value']
		if codepath == code:
			tagpath = keypath
	tag = system.tag.readBlocking(tagpath)[0]
	dekey_tag = system.util.jsonEncode(tag)
	dekey_tag = system.util.jsonDecode(dekey_tag)
	
	linkedcode = dekey_tag['value']['members']['linked_to_code']['value']
	return linkedcode

def real_text(tagfolder,code):
	tagbrowse = system.tag.browse(tagfolder)
	for i in range(len(tagbrowse)):
		keypath = str(tagbrowse[i]['fullPath'])
		keyval = tagbrowse[i]['value']
		dekey = system.util.jsonEncode(keyval)
		dekey = system.util.jsonDecode(dekey)
		codepath = dekey['value']['members']['code']['value']
		if codepath == code:
			tagpath = keypath
	tag = system.tag.readBlocking(tagpath)[0]
	dekey_tag = system.util.jsonEncode(tag)
	dekey_tag = system.util.jsonDecode(dekey_tag)
	
	real_text = dekey_tag['value']['members']['real_text']['value']
	return real_text
	

def key_finder(tagfolder,code,key):
	tagbrowse = system.tag.browse(tagfolder)
	for i in range(len(tagbrowse)):
		keypath = str(tagbrowse[i]['fullPath'])
		keyval = tagbrowse[i]['value']
		dekey = system.util.jsonEncode(keyval)
		dekey = system.util.jsonDecode(dekey)
		codepath = dekey['value']['members']['code']['value']
		if codepath == code:
			tagpath = keypath
	tag = system.tag.readBlocking(tagpath)[0]
	dekey_tag = system.util.jsonEncode(tag)
	dekey_tag = system.util.jsonDecode(dekey_tag)
	
	code = dekey_tag['value']['members'][key]['value']
	return code
	
def card_set(set,deckname,deckfolder):
	cardset = []
	tagbrowse = system.tag.browse('[default]Cards')
	for i in range(len(tagbrowse)):
		carddict = {}
		keypath = str(tagbrowse[i]['fullPath'])
		keyval = tagbrowse[i]['value']
		dekey = system.util.jsonEncode(keyval)
		dekey = system.util.jsonDecode(dekey)
		try:
			codepath = dekey['value']['members']['card_set_code']['value']
			if codepath == set:
				tagpath = keypath
				tag = system.tag.readBlocking(tagpath)[0]
				dekey_tag = system.util.jsonEncode(tag)
				dekey_tag = system.util.jsonDecode(dekey_tag)
				try:
			  		code = dekey_tag['value']['members']['code']['value']
			  	except:
			  		code = ''
			  	try:
			  		name = dekey_tag['value']['members']['name']['value']
			  	except:
			  		name = ''
			  	try:
			  		cost = dekey_tag['value']['members']['cost']['value']
			  	except:
			  		cost = 0
			  	try:	
			  		quantity = dekey_tag['value']['members']['quantity']['value']
			  	except:
			  		quantity = 0
			  	try:
			  		text = dekey_tag['value']['members']['text']['value']
			  	except:
			  		text = ''
			  	try:
			  		url = dekey_tag['value']['members']['url']['value']
			  	except:
			  		url = ''
			  	try:
			  		type_name = dekey_tag['value']['members']['type_name']['value']
			  	except:
			  		type_name = ''
			  	try:
			  		resource_mental = dekey_tag['value']['members']['resource_mental']['value']
			  	except:
			  		resource_mental = 0
			  	try:
			  		resource_physical = dekey_tag['value']['members']['resource_physical']['value']
			  	except:
			  		resource_physical = 0
			  	try:
			  		resource_energy = dekey_tag['value']['members']['resource_energy']['value']
			  	except:
			  		resource_energy = 0
			  	try:
			  		resource_wild = dekey_tag['value']['members']['resource_wild']['value']
			  	except:
			  		resource_wild = 0
			  	try: 
			  		health = dekey_tag['value']['members']['health']['value']
			  	except:
			  		health = 0
			  	try: 
			  		thwart = dekey_tag['value']['members']['thwart']['value'] 
			  	except:
			  		thwart = 0	  	
			  	try: 
			  		attack = dekey_tag['value']['members']['attack']['value'] 	  	 	  	
			  	except:
			  		attack = 0
			  	carddict = {'code':code, 'name':name, 'type_name':type_name, 'cost':cost, 'quantity':quantity, 'text':text, 'url':url, 'resource_mental':resource_mental, 'resource_physical':resource_physical, 'resource_energy':resource_energy, 'resource_wild':resource_wild, 'health':health, 'attack':attack, 'thwart':thwart}
			  	cardset.append(carddict)
		except:
			pass
	tag = {
	        "name": deckname,         
	        "dataType" : 'Document',
	        "tagType" : 'AtomicTag',
	        "value" : cardset
	    }
	tag = system.util.jsonEncode(tag)
	tag = system.util.jsonDecode(tag)
	try:
		system.tag.configure(deckfolder, tag)
		status = 'Success!'
	except:
		status = 'Fail...'
	return 	status
	
def aspect_cards(factioncode,deckname,deckfolder):
	cardset = []
	tagbrowse = system.tag.browse('[default]Cards')
	for i in range(len(tagbrowse)):
		carddict = {}
		keypath = str(tagbrowse[i]['fullPath'])
		keyval = tagbrowse[i]['value']
		dekey = system.util.jsonEncode(keyval)
		dekey = system.util.jsonDecode(dekey)
		try:
			codepath = dekey['value']['members']['faction_code']['value']
			if codepath == factioncode:
				tagpath = keypath
				tag = system.tag.readBlocking(tagpath)[0]
				dekey_tag = system.util.jsonEncode(tag)
				dekey_tag = system.util.jsonDecode(dekey_tag)
				try:
					code = dekey_tag['value']['members']['code']['value']
				except:
					code = ' '
				try:
					name = dekey_tag['value']['members']['name']['value']
				except:
					name = ' '
				try:
					cost = dekey_tag['value']['members']['cost']['value']
				except:
					cost = 0
				try:
					quantity = dekey_tag['value']['members']['quantity']['value']
				except:
					quantity = 0
				try:
					text = dekey_tag['value']['members']['text']['value']
				except:
					text = ' '
				try:
					url = dekey_tag['value']['members']['url']['value']
				except:
					url = ' '
				try:
					type_name = dekey_tag['value']['members']['type_name']['value']
				except:
					type_name = ' '
				try:
					resource_mental = dekey_tag['value']['members']['resource_mental']['value']
				except:
					resource_mental = 0
				try:
					resource_physical = dekey_tag['value']['members']['resource_physical']['value']
				except:
					resource_physical = 0
				try:
					resource_energy = dekey_tag['value']['members']['resource_energy']['value']
				except:
					resource_energy = 0
				try:
					resource_wild = dekey_tag['value']['members']['resource_wild']['value']
				except:
					resource_wild = 0
				try: 
					health = dekey_tag['value']['members']['health']['value']
				except:
					health = 0
				try: 
					thwart = dekey_tag['value']['members']['thwart']['value'] 
				except:
					thwart = 0	  	
				try: 
					attack = dekey_tag['value']['members']['attack']['value'] 	  	 	  	
				except:
					attack = 0
				carddict = {'code':code, 'name':name, 'type_name':type_name, 'cost':cost, 'quantity':quantity, 'text':text, 'url':url, 'resource_mental':resource_mental, 'resource_physical':resource_physical, 'resource_energy':resource_energy, 'resource_wild':resource_wild, 'health':health, 'attack':attack, 'thwart':thwart}
				cardset.append(carddict)
		except:
			pass
	tag = {
			"name": deckname,         
			"dataType" : 'Document',
			"tagType" : 'AtomicTag',
			"value" : cardset
			    }
	tag = system.util.jsonEncode(tag)
	tag = system.util.jsonDecode(tag)
	try:
		system.tag.configure(deckfolder, tag)
		status = 'Success!'
	except:
		status = 'Fail...'
	return 	status
	
def aspect_type(factioncode,typecode,deckname,deckfolder):
	cardset = []
	tagbrowse = system.tag.browse('[default]Cards')
	for i in range(len(tagbrowse)):
		carddict = {}
		keypath = str(tagbrowse[i]['fullPath'])
		keyval = tagbrowse[i]['value']
		dekey = system.util.jsonEncode(keyval)
		dekey = system.util.jsonDecode(dekey)
		try:
			codepath = dekey['value']['members']['faction_code']['value']
			typepath = dekey['value']['members']['type_code']['value']
			if codepath == factioncode and typepath == typecode:
				tagpath = keypath
				tag = system.tag.readBlocking(tagpath)[0]
				dekey_tag = system.util.jsonEncode(tag)
				dekey_tag = system.util.jsonDecode(dekey_tag)
				try:
					code = dekey_tag['value']['members']['code']['value']
				except:
					code = ' '
				try:
					name = dekey_tag['value']['members']['name']['value']
				except:
					name = ' '
				try:
					cost = dekey_tag['value']['members']['cost']['value']
				except:
					cost = 0
				try:
					quantity = dekey_tag['value']['members']['quantity']['value']
				except:
					quantity = 0
				try:
					text = dekey_tag['value']['members']['text']['value']
				except:
					text = ' '
				try:
					url = dekey_tag['value']['members']['url']['value']
				except:
					url = ' '
				try:
					type_name = dekey_tag['value']['members']['type_name']['value']
				except:
					type_name = ' '
				try:
					resource_mental = dekey_tag['value']['members']['resource_mental']['value']
				except:
					resource_mental = 0
				try:
					resource_physical = dekey_tag['value']['members']['resource_physical']['value']
				except:
					resource_physical = 0
				try:
					resource_energy = dekey_tag['value']['members']['resource_energy']['value']
				except:
					resource_energy = 0
				try:
					resource_wild = dekey_tag['value']['members']['resource_wild']['value']
				except:
					resource_wild = 0
				try: 
					health = dekey_tag['value']['members']['health']['value']
				except:
					health = 0
				try: 
					thwart = dekey_tag['value']['members']['thwart']['value'] 
				except:
					thwart = 0	  	
				try: 
					attack = dekey_tag['value']['members']['attack']['value'] 	  	 	  	
				except:
					attack = 0
				carddict = {'code':code, 'name':name, 'type_name':type_name, 'cost':cost, 'quantity':quantity, 'text':text, 'url':url, 'resource_mental':resource_mental, 'resource_physical':resource_physical, 'resource_energy':resource_energy, 'resource_wild':resource_wild, 'health':health, 'attack':attack, 'thwart':thwart}
				cardset.append(carddict)
		except:
			pass
	tag = {
			"name": deckname,         
			"dataType" : 'Document',
			"tagType" : 'AtomicTag',
			"value" : cardset
			    }
	tag = system.util.jsonEncode(tag)
	tag = system.util.jsonDecode(tag)
	try:
		system.tag.configure(deckfolder, tag)
		status = 'Success!'
	except:
		status = 'Fail...'
	return 	status
	
def deck_write(deckname):
	data = system.tag.readBlocking('[Default]Decks/'+deckname)[0].value
	for x in range(len(data)):
	    colkey = data[x]
	    colval = list(colkey.values())
	    colval.append(deckname)
	    n = system.db.runPrepUpdate("INSERT INTO deckname (type_name, code, cost, quantity, thwart, resource_mental,health, resource_physical, url, attack, name,text, resource_energy, resource_wild, deckname) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", colval,"MarvelDB")