SELECT cost, SUM(quantity) as [count]
FROM deckname
WHERE deckname = :deck
GROUP BY cost