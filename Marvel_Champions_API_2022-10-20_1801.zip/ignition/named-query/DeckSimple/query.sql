SELECT
    SUM(quantity) AS [quantity],
    SUM(resource_energy) AS [Energy],
    SUM(resource_mental) AS [Mental],
    SUM(resource_physical) AS [Physical],
    SUM(resource_wild) AS [Wild]
FROM deckname
WHERE [deckname] = :deck