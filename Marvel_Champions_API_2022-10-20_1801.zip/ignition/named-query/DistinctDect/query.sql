SELECT DISTINCT deckname
FROM deckname