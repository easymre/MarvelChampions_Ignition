SELECT name, type_name, quantity, text, id
FROM deckname
WHERE deckname = :deck